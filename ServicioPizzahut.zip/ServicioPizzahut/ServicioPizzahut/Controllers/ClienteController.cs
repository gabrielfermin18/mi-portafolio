﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ServicioPizzahut.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ServicioPizzahut.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClienteController : ControllerBase
    {
        private readonly BdbigBengContext db;
        public ClienteController(BdbigBengContext _db)
        {
            db = _db;
        }



        // GET: api/<ClienteController>
        [HttpGet("GetClientes")]
        public async Task<ActionResult<List<Cliente>>> GetClientes()
        {
            return await db.Clientes.ToListAsync();
        }

        // GET api/<ClienteController>/5
        [HttpGet("GetCliente/{id}")]
        public async Task<ActionResult<Cliente>> GetCliente(string id)
        {
            var buscado = await db.Clientes.FindAsync(id);
            if (buscado == null)
            {
                return BadRequest($"El codigo del Cliente {id} NO EXISTE");

            }
            return Ok(buscado);
        }

        // POST api/<ClienteController>
        [HttpPost("GrabarClientePost")]
        public async Task<ActionResult<string>> GrabarClientePost([FromBody] Cliente obj)
        {
            try
            {
                
                await db.Clientes.AddAsync(obj);//graba en memoria
                await db.SaveChangesAsync();// graba en la BD
                return $"Se registro al nuevo medico: {obj.Nombre}";
            }
            catch (Exception ex)
            {
                return BadRequest("" + ex.InnerException!.Message);
            }
        }

        // PUT api/<ClienteController>/5
        [HttpPut("ActualizarClientePut")]
        public async Task<ActionResult<string>> ActualizarClientePut([FromBody] Cliente obj)
        {
            try
            {
                await Task.Run(() => db.Clientes.Update(obj));//graba en memoria
                await db.SaveChangesAsync();// graba en la BD
                return $"Se actualizo al medico: {obj.Nombre}";
            }
            catch (Exception ex)
            {
                return BadRequest("" + ex.InnerException!.Message);
            }
        }

        // DELETE api/<ClienteController>/5
        [HttpDelete("DeleteCliente/{id}")]
        public async Task<ActionResult<string>> DeleteCliente(string id)
        {
            try
            {
                var buscado = await db.Clientes.FindAsync(id);
                if (buscado == null)
                {
                    return BadRequest("Codigo NO Encontrado");
                }

                

                await db.SaveChangesAsync();
                return $"El medico : {buscado.Nombre} " +
                        "fue eliminado de forma logica";
            }
            catch (Exception ex)
            {
                return BadRequest(ex.InnerException!.Message);
            }

        }
    }
}
