﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace ServicioPizzahut.Models;

public partial class BdbigBengContext : DbContext
{
    public BdbigBengContext()
    {
    }

    public BdbigBengContext(DbContextOptions<BdbigBengContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Cliente> Clientes { get; set; }

    public virtual DbSet<DetallePedido> DetallePedidos { get; set; }

    public virtual DbSet<Empleado> Empleados { get; set; }

    public virtual DbSet<Entrega> Entregas { get; set; }

    public virtual DbSet<Pedido> Pedidos { get; set; }

    public virtual DbSet<Pizza> Pizzas { get; set; }

    //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
  //      => optionsBuilder.UseSqlServer("server=localhost;database=BDBigBeng;User ID=sa;Password=sql;TrustServerCertificate=false;Encrypt=false;");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Cliente>(entity =>
        {
            entity.HasKey(e => e.IdCliente).HasName("PK__Clientes__677F38F57C0A816E");

            entity.Property(e => e.IdCliente)
                .HasMaxLength(10)
                .HasColumnName("id_cliente");
            entity.Property(e => e.Apellido)
                .HasMaxLength(50)
                .HasColumnName("apellido");
            entity.Property(e => e.Direccion)
                .HasMaxLength(100)
                .HasColumnName("direccion");
            entity.Property(e => e.Nombre)
                .HasMaxLength(50)
                .HasColumnName("nombre");
            entity.Property(e => e.Telefono)
                .HasMaxLength(15)
                .HasColumnName("telefono");
        });

        modelBuilder.Entity<DetallePedido>(entity =>
        {
            entity.HasKey(e => e.IdDetalle).HasName("PK__Detalle___4F1332DEE92E2005");

    

            entity.Property(e => e.IdDetalle)
                .HasMaxLength(10)
                .HasColumnName("id_detalle");
            entity.Property(e => e.Cantidad).HasColumnName("cantidad");
            entity.Property(e => e.IdPedido)
                .HasMaxLength(10)
                .HasColumnName("id_pedido");
            entity.Property(e => e.IdPizza)
                .HasMaxLength(10)
                .HasColumnName("id_pizza");

            entity.HasOne(d => d.IdPedidoNavigation).WithMany(p => p.DetallePedidos)
                .HasForeignKey(d => d.IdPedido)
                .OnDelete(DeleteBehavior.SetNull)
                .HasConstraintName("FK__Detalle_P__id_pe__412EB0B6");

            entity.HasOne(d => d.IdPizzaNavigation).WithMany(p => p.DetallePedidos)
                .HasForeignKey(d => d.IdPizza)
                .OnDelete(DeleteBehavior.SetNull)
                .HasConstraintName("FK__Detalle_P__id_pi__4222D4EF");
        });

        modelBuilder.Entity<Empleado>(entity =>
        {
            entity.HasKey(e => e.IdEmpleado).HasName("PK__Empleado__88B51394CAF14835");

            entity.ToTable("Empleado");

            entity.Property(e => e.IdEmpleado)
                .HasMaxLength(10)
                .HasColumnName("id_empleado");
            entity.Property(e => e.Apellido)
                .HasMaxLength(50)
                .HasColumnName("apellido");
            entity.Property(e => e.Nombre)
                .HasMaxLength(50)
                .HasColumnName("nombre");
            entity.Property(e => e.Rol)
                .HasMaxLength(50)
                .HasColumnName("rol");
            entity.Property(e => e.Telefono)
                .HasMaxLength(15)
                .HasColumnName("telefono");
        });

        modelBuilder.Entity<Entrega>(entity =>
        {
            entity.HasKey(e => e.IdEntrega).HasName("PK__Entregas__017C2C8A052604C2");

            entity.Property(e => e.IdEntrega)
                .HasMaxLength(10)
                .HasColumnName("id_entrega");
            entity.Property(e => e.EstadoEntrega)
                .HasMaxLength(50)
                .HasColumnName("estado_entrega");
            entity.Property(e => e.FechaHoraEntrega)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("fecha_hora_entrega");
            entity.Property(e => e.IdEmpleado)
                .HasMaxLength(10)
                .HasColumnName("id_empleado");
            entity.Property(e => e.IdPedido)
                .HasMaxLength(10)
                .HasColumnName("id_pedido");

            entity.HasOne(d => d.IdEmpleadoNavigation).WithMany(p => p.Entregas)
                .HasForeignKey(d => d.IdEmpleado)
                .HasConstraintName("FK__Entregas__id_emp__46E78A0C");

            entity.HasOne(d => d.IdPedidoNavigation).WithMany(p => p.Entregas)
                .HasForeignKey(d => d.IdPedido)
                .OnDelete(DeleteBehavior.SetNull)
                .HasConstraintName("FK__Entregas__id_ped__45F365D3");
        });

        modelBuilder.Entity<Pedido>(entity =>
        {
            entity.HasKey(e => e.IdPedido).HasName("PK__Pedidos__6FF014891F9BDD89");

            entity.Property(e => e.IdPedido)
                .HasMaxLength(10)
                .HasColumnName("id_pedido");
            entity.Property(e => e.Estado)
                .HasMaxLength(50)
                .HasColumnName("estado");
            entity.Property(e => e.FechaHora)
                .HasDefaultValueSql("(getdate())")
                .HasColumnType("datetime")
                .HasColumnName("fecha_hora");
            entity.Property(e => e.IdCliente)
                .HasMaxLength(10)
                .HasColumnName("id_cliente");
            entity.Property(e => e.Total)
                .HasColumnType("decimal(10, 2)")
                .HasColumnName("total");

            entity.HasOne(d => d.IdClienteNavigation).WithMany(p => p.Pedidos)
                .HasForeignKey(d => d.IdCliente)
                .HasConstraintName("FK__Pedidos__id_clie__3E52440B");
        });

        modelBuilder.Entity<Pizza>(entity =>
        {
            entity.HasKey(e => e.IdPizza).HasName("PK__Pizzas__3BA25C0889D79C88");

            entity.Property(e => e.IdPizza)
                .HasMaxLength(10)
                .HasColumnName("id_pizza");
            entity.Property(e => e.Descripcion)
                .HasMaxLength(100)
                .HasColumnName("descripcion");
            entity.Property(e => e.Nombre)
                .HasMaxLength(100)
                .HasColumnName("nombre");
            entity.Property(e => e.Precio)
                .HasColumnType("decimal(10, 2)")
                .HasColumnName("precio");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
