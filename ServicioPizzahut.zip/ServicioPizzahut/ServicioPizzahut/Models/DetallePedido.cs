﻿using System;
using System.Collections.Generic;

namespace ServicioPizzahut.Models;

public partial class DetallePedido
{
    public string IdDetalle { get; set; } = null!;

    public string? IdPedido { get; set; }

    public string? IdPizza { get; set; }

    public int? Cantidad { get; set; }

    public virtual Pedido? IdPedidoNavigation { get; set; }

    public virtual Pizza? IdPizzaNavigation { get; set; }
}
