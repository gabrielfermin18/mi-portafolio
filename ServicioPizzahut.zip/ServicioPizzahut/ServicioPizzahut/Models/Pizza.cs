﻿using System;
using System.Collections.Generic;

namespace ServicioPizzahut.Models;

public partial class Pizza
{
    public string IdPizza { get; set; } = null!;

    public string? Nombre { get; set; }

    public string? Descripcion { get; set; }

    public decimal? Precio { get; set; }

    public virtual ICollection<DetallePedido> DetallePedidos { get; set; } = new List<DetallePedido>();
}
