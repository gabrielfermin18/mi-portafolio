﻿using System;
using System.Collections.Generic;

namespace ServicioPizzahut.Models;

public partial class Entrega
{
    public string IdEntrega { get; set; } = null!;

    public string? IdPedido { get; set; }

    public string? IdEmpleado { get; set; }

    public DateTime? FechaHoraEntrega { get; set; }

    public string? EstadoEntrega { get; set; }

    public virtual Empleado? IdEmpleadoNavigation { get; set; }

    public virtual Pedido? IdPedidoNavigation { get; set; }
}
