﻿using System;
using System.Collections.Generic;

namespace ServicioPizzahut.Models;

public partial class Empleado
{
    public string IdEmpleado { get; set; } = null!;

    public string? Nombre { get; set; }

    public string? Apellido { get; set; }

    public string? Rol { get; set; }

    public string? Telefono { get; set; }

    public virtual ICollection<Entrega> Entregas { get; set; } = new List<Entrega>();
}
