﻿using System;
using System.Collections.Generic;

namespace ServicioPizzahut.Models;

public partial class Pedido
{
    public string IdPedido { get; set; } = null!;

    public DateTime? FechaHora { get; set; }

    public decimal? Total { get; set; }

    public string? Estado { get; set; }

    public string? IdCliente { get; set; }

    public virtual ICollection<DetallePedido> DetallePedidos { get; set; } = new List<DetallePedido>();

    public virtual ICollection<Entrega> Entregas { get; set; } = new List<Entrega>();

    public virtual Cliente? IdClienteNavigation { get; set; }
}
