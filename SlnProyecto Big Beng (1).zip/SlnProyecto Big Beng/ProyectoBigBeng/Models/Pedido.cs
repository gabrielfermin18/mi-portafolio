﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace ProyectoBigBeng.Models
{
    public class Pedido
    {
        [DisplayName("ID Pedido")]
        [Required(ErrorMessage = "El id del pedido es obligatorio")]
        public string IdPedido { get; set; }

        [DisplayName("Fecha y Hora")]
        public DateTime FechaHora { get; set; }

        [DisplayName("Total del Pedido")]
        [Required(ErrorMessage = "El total del pedido es obligatorio")]
        public decimal Total { get; set; }

        [DisplayName("Estado del Pedido")]
        [Required(ErrorMessage = "El estado del pedido es obligatorio")]
        public string Estado { get; set; }

        // Relación con la clase Cliente
        public string IdCliente { get; set; }
        public Clientes Cliente { get; set; }

        // Relación con los detalles del pedido
        public List<DetallePedido> Detalles { get; set; }
    }
}

