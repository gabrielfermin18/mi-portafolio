﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProyectoBigBeng.Models
{
    public class Clientes
    {
        [Column("idCliente")]
        [DisplayName("ID Cliente")]
        [Required(ErrorMessage = "El id del cliente es obligatorio")]
        public string Id { get; set; } = "";

        [Column("nombre")]
        [DisplayName("Nombre del Cliente")]
        [Required(ErrorMessage = "El nombre del cliente es obligatorio")]
        public string Nombre { get; set; }

        [Column("apellido")]
        [DisplayName("Apellido del Cliente")]
        [Required(ErrorMessage = "El apellido del cliente es obligatorio")]
        public string Apellido { get; set; }

        [Column("telefono")]
        [DisplayName("Teléfono del Cliente")]
        [Required(ErrorMessage = "El teléfono del cliente es obligatorio")]
        public string Telefono { get; set; }

        [Column("direccion")]
        [DisplayName("Dirección del Cliente")]
        [Required(ErrorMessage = "La dirección del cliente es obligatoria")]
        public string Direccion { get; set; }
    }
}