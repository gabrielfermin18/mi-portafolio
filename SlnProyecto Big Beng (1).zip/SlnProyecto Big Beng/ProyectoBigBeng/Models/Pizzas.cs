﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace ProyectoBigBeng.Models
{
    public class Pizzas
    {
        [Column("id_pizza")]
        [DisplayName("ID Pizza")]
        [Required(ErrorMessage = "El id de la pizza es obligatorio")]
        public string id_pizza { get; set; }

        [Column("nombre")]
        [DisplayName("Nombre de la pizza")]
        [Required(ErrorMessage = "El nombre de la pizza es obligatorio")]
        public string nombre { get; set; }

        [Column("descripcion")]
        [DisplayName("Descripción de la pizza")]
        [Required(ErrorMessage = "La descripción de la pizza es obligatoria")]
        public string descripcion { get; set; }

        [Column("precio")]
        [DisplayName("Precio de la pizza")]
        [Required(ErrorMessage = "El precio de la pizza es obligatorio")]
        public decimal precio { get; set; }
    }
}
