﻿namespace ProyectoBigBeng.Models
{
    public class Entregas
    {
    }
}
