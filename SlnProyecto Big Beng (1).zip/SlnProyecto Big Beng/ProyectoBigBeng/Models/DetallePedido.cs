﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace ProyectoBigBeng.Models
{
    public class DetallePedido
    {
        [DisplayName("ID Detalle")]
        [Required(ErrorMessage = "El id del detalle es obligatorio")]
        public string IdDetalle { get; set; }

        [DisplayName("ID Pedido")]
        [Required(ErrorMessage = "El id del pedido es obligatorio")]
        public string IdPedido { get; set; }

        [DisplayName("ID Pizza")]
        [Required(ErrorMessage = "El id de la pizza es obligatorio")]
        public string IdPizza { get; set; }

        [DisplayName("Cantidad de Pizzas")]
        [Required(ErrorMessage = "La cantidad de pizzas es obligatoria")]
        public int Cantidad { get; set; }

        // Relación con la clase Pedido
        public Pedido Pedido { get; set; }

        // Relación con la clase Pizza
        public Pizzas Pizza { get; set; }

        // Propiedad calculada para el subtotal
        public decimal Subtotal
        {
            get
            {
                if (Pizza != null)
                {
                    return Cantidad * Pizza.precio; // Asumiendo que Pizza tiene una propiedad Precio
                }
                return 0;
            }
        }
    }
}


