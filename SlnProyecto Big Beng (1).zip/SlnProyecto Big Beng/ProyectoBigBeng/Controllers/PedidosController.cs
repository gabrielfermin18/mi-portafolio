﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using ProyectoBigBeng.Models;
using System.Data;

namespace ProyectoBigBeng.Controllers
{
    public class PedidosController : Controller
    {
        private string cad_cnx = "";

        public PedidosController(IConfiguration _cfg)
        {
            cad_cnx = _cfg.GetConnectionString("cn1");
        }

        // GET: Crear Pedido
        [HttpGet]
        public IActionResult CrearPedido()
        {
            return View();
        }

        // Crear Pedido (POST)
        [HttpPost]
        public IActionResult CrearPedido(Pedido pedido)
        {
            if (ModelState.IsValid)
            {
                using (SqlConnection con = new SqlConnection(cad_cnx))
                {
                    SqlCommand cmd = new SqlCommand("sp_InsertarPedido", con)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                    cmd.Parameters.Add("@id_pedido", SqlDbType.NVarChar).Value = pedido.IdPedido;
                    cmd.Parameters.Add("@id_cliente", SqlDbType.NVarChar).Value = pedido.IdCliente;
                    cmd.Parameters.Add("@fecha_hora", SqlDbType.DateTime).Value = pedido.FechaHora;
                    cmd.Parameters.Add("@total", SqlDbType.Decimal).Value = pedido.Total;

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
                return RedirectToAction("ListarPedidos");
            }
            return View(pedido);
        }

        // Listar Todos los Pedidos
        public IActionResult ListarPedidos(string searchCodigo, int? page)
        {
            List<Pedido> pedidos = new List<Pedido>();
            var pageNumber = page ?? 1;  // Si no se pasa un número de página, usa la página 1
            var pageSize = 10;  // Tamaño de la página (puedes ajustarlo)

            using (SqlConnection con = new SqlConnection(cad_cnx))
            {
                SqlCommand cmd;
                if (!string.IsNullOrEmpty(searchCodigo))
                {
                    // Buscar pedido por código
                    cmd = new SqlCommand("sp_ObtenerPedidoPorID", con)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                    cmd.Parameters.Add("@id_pedido", SqlDbType.NVarChar).Value = searchCodigo;
                }
                else
                {
                    // Listar todos los pedidos
                    cmd = new SqlCommand("sp_ListarPedidos", con)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                }

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    pedidos.Add(new Pedido
                    {
                        IdPedido = reader["id_pedido"].ToString(),
                        IdCliente = reader["id_cliente"].ToString(),
                        FechaHora = Convert.ToDateTime(reader["fecha_hora"]),
                        Total = Convert.ToDecimal(reader["total"])
                    });
                }
                con.Close();
            }

            // Obtiene la lista paginada
            var pagedPedidos = PagedList<Pedido>.GetPagedList(pedidos, pageNumber, pageSize);

            return View(pagedPedidos);
        }

        // Ver Detalles del Pedido
        public IActionResult DetallePedido(string id)
        {
            Pedido pedido = null;
            using (SqlConnection con = new SqlConnection(cad_cnx))
            {
                SqlCommand cmd = new SqlCommand("sp_ObtenerPedidosPorID", con)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.Add("@id_pedido", SqlDbType.NVarChar).Value = id;

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        pedido = new Pedido
                        {
                            IdPedido = reader["id_pedido"].ToString(),
                            IdCliente = reader["id_cliente"].ToString(),
                            FechaHora = Convert.ToDateTime(reader["fecha_hora"]),
                            Total = Convert.ToDecimal(reader["total"])
                        };
                    }
                }
                con.Close();
            }

            if (pedido == null)
            {
                return NotFound();
            }
            return View(pedido);
        }

        // Eliminar Pedido (POST)
        [HttpPost]
        public IActionResult EliminarPedido(string id)
        {
            using (SqlConnection con = new SqlConnection(cad_cnx))
            {
                SqlCommand cmd = new SqlCommand("sp_EliminarPedido", con)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.Add("@id_pedido", SqlDbType.NVarChar).Value = id;

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            return RedirectToAction("ListarPedidos");
        }

        // Editar Pedido (GET)
        public IActionResult EditarPedido(string id)
        {
            Pedido pedido = null;
            using (SqlConnection con = new SqlConnection(cad_cnx))
            {
                SqlCommand cmd = new SqlCommand("sp_ObtenerPedidoPorID", con)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.Add("@id_pedido", SqlDbType.NVarChar).Value = id;

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        pedido = new Pedido
                        {
                            IdPedido = reader["id_pedido"].ToString(),
                            IdCliente = reader["id_cliente"].ToString(),
                            FechaHora = Convert.ToDateTime(reader["fecha_hora"]),
                            Total = Convert.ToDecimal(reader["total"])
                        };
                    }
                }
                con.Close();
            }

            if (pedido == null)
            {
                return NotFound();
            }
            return View(pedido);
        }

        // Actualizar Pedido (POST)
        [HttpPost]
        public IActionResult EditarPedido(Pedido pedido)
        {
            if (ModelState.IsValid)
            {
                using (SqlConnection con = new SqlConnection(cad_cnx))
                {
                    SqlCommand cmd = new SqlCommand("sp_ActualizarPedido", con)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                    cmd.Parameters.Add("@id_pedido", SqlDbType.NVarChar).Value = pedido.IdPedido;
                    cmd.Parameters.Add("@id_cliente", SqlDbType.NVarChar).Value = pedido.IdCliente;
                    cmd.Parameters.Add("@fecha_hora", SqlDbType.DateTime).Value = pedido.FechaHora;
                    cmd.Parameters.Add("@total", SqlDbType.Decimal).Value = pedido.Total;

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
                return RedirectToAction("ListarPedidos");
            }
            return View(pedido);
        }
    }
}
