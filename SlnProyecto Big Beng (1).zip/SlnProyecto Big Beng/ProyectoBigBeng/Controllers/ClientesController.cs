﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using ProyectoBigBeng.Models;
using System.Data;
using Newtonsoft.Json;
using System.Text;

namespace ProyectoBigBeng.Controllers
{
    public class ClientesController : Controller
    {
        private string cad_cnx = "";

        public ClientesController(IConfiguration _cfg)
        {
            cad_cnx = _cfg.GetConnectionString("cn1");
        }


        // ********** INICIO DE METODOS *****************

        // Listar Todos los Clientes


        List<Clientes> listaclientes = new List<Clientes>();
        public async Task<List<Clientes>> traerClientes()
        {
            using (HttpClient client = new HttpClient())
            {
                // realizar la solicitud
                var respuesta = await client.GetAsync(
                    "http://localhost:5102/api/Cliente/GetClientes");

                // convertir el contenido devuelto a un string
                string cadena = await respuesta.Content.ReadAsStringAsync();

                // deserializamos la cadena json a una lista de medicos
                return JsonConvert.DeserializeObject<List<Clientes>>(cadena)!;
            }

        }

       

        public async Task<string> ejecutarMetodoWeb(
            int opc, Clientes? objmed, string id = "")
        {
            string cadena = string.Empty;

            using (HttpClient cliente = new HttpClient())
            {
                // realizar la solicitud
                HttpResponseMessage respuesta = new HttpResponseMessage();

                StringContent contenido = new StringContent(
                JsonConvert.SerializeObject(objmed), Encoding.UTF8, "application/json");

                if (opc == 1)
                    respuesta = await cliente.PostAsync(
                    "http://localhost:5102/api/Cliente/GrabarClientePost", contenido);
                else if (opc == 2)
                    respuesta = await cliente.PutAsync(
                    "http://localhost:5102/api/Cliente/ActualizarClientePut", contenido);
                else
                    respuesta = await cliente.DeleteAsync(
                    "http://localhost:5102/api/ClinicaAPI/DeleteCliente/" + id);


                // convertir el contenido devuelto a un string
                cadena = await respuesta.Content.ReadAsStringAsync();

            }
            // retornamos el mensaje de la variable cadena 
            return cadena;
        }
        //********* FIN DE LOS METODOS ****************************

        public async Task<ActionResult> ListarClientes()
        {
            listaclientes = await traerClientes();
            return View(listaclientes);
        }


        

        // GET: Crear Cliente
        [HttpGet]
        public ActionResult CrearClientes()
        {
            return View(new Clientes());

        }
        

        /*
        // POST: ClinicaMVCController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> CreateCliente(Clientes obj)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    TempData["mensaje"] =
                        await ejecutarMetodoWeb(1, obj, "");

                    return RedirectToAction(nameof(ListarClientes));
                }

            }
            catch (Exception ex)
            {
                ViewBag.Message = ex.Message;
            }
            return View(obj);
        }
        */

        

        // Crear Cliente
        [HttpPost]
        public IActionResult CrearClientes(Clientes cliente)
        {
            if (ModelState.IsValid)
            {
                using (SqlConnection con = new SqlConnection(cad_cnx))
                {
                    SqlCommand cmd = new SqlCommand("sp_InsertarCliente", con)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                    cmd.Parameters.Add("@id_cliente", SqlDbType.NVarChar).Value = cliente.Id;
                    cmd.Parameters.Add("@nombre", SqlDbType.NVarChar).Value = cliente.Nombre;
                    cmd.Parameters.Add("@apellido", SqlDbType.NVarChar).Value = cliente.Apellido;
                    cmd.Parameters.Add("@telefono", SqlDbType.NVarChar).Value = cliente.Telefono;
                    cmd.Parameters.Add("@direccion", SqlDbType.NVarChar).Value = cliente.Direccion;

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
                return RedirectToAction("ListarClientes");
            }
            return View(cliente);
        }
        

        // Leer Cliente por ID
        public IActionResult LeerClientes(string id)
        {
            Clientes cliente = null;
            using (SqlConnection con = new SqlConnection(cad_cnx))
            {
                SqlCommand cmd = new SqlCommand("sp_ObtenerClientePorID", con)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.Add("@id_cliente", SqlDbType.NVarChar).Value = id;

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        cliente = new Clientes
                        {
                            Id = reader["id_cliente"].ToString(),
                            Nombre = reader["nombre"].ToString(),
                            Apellido = reader["apellido"].ToString(),
                            Telefono = reader["telefono"].ToString(),
                            Direccion = reader["direccion"].ToString()
                        };
                    }
                }
                con.Close();
            }

            if (cliente == null)
            {
                return NotFound(); // O redirigir a otra vista de error
            }
            return View(cliente);
        }

        

        /*
        public IActionResult ListarClientes(string searchCodigo)
        {
            List<Clientes> clientes = new List<Clientes>();

            using (SqlConnection con = new SqlConnection(cad_cnx))
            {
                SqlCommand cmd;
                if (!string.IsNullOrEmpty(searchCodigo))
                {
                    // Busca por código
                    cmd = new SqlCommand("sp_ObtenerClientePorID", con)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                    cmd.Parameters.Add("@id_cliente", SqlDbType.NVarChar).Value = searchCodigo;
                }
                else
                {
                    // Lista todos los clientes
                    cmd = new SqlCommand("sp_ListarClientes", con)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                }

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    clientes.Add(new Clientes
                    {
                        Id = reader["id_cliente"].ToString(),
                        Nombre = reader["nombre"].ToString(),
                        Apellido = reader["apellido"].ToString(),
                        Telefono = reader["telefono"].ToString(),
                        Direccion = reader["direccion"].ToString()
                    });
                }
                con.Close();
            }

            return View(clientes);
        }
        */

        // Método GET para cargar los datos del cliente para la edición
        public IActionResult EditarClientes(string id)
        {
            Clientes cliente = null;
            using (SqlConnection con = new SqlConnection(cad_cnx))
            {
                SqlCommand cmd = new SqlCommand("sp_ObtenerClientePorID", con)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.Add("@id_cliente", SqlDbType.NVarChar).Value = id;

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        cliente = new Clientes
                        {
                            Id = reader["id_cliente"].ToString(),
                            Nombre = reader["nombre"].ToString(),
                            Apellido = reader["apellido"].ToString(),
                            Telefono = reader["telefono"].ToString(),
                            Direccion = reader["direccion"].ToString()
                        };
                    }
                }
                con.Close();
            }

            if (cliente == null)
            {
                return NotFound(); // O redirigir a otra vista de error
            }
            return View(cliente);
        }

        // Actualizar Cliente (Método POST)
        [HttpPost]
        public IActionResult EditarClientes(Clientes cliente)
        {
            if (ModelState.IsValid)
            {
                using (SqlConnection con = new SqlConnection(cad_cnx))
                {
                    SqlCommand cmd = new SqlCommand("sp_ActualizarCliente", con)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                    cmd.Parameters.Add("@id_cliente", SqlDbType.NVarChar).Value = cliente.Id;
                    cmd.Parameters.Add("@nombre", SqlDbType.NVarChar).Value = cliente.Nombre;
                    cmd.Parameters.Add("@apellido", SqlDbType.NVarChar).Value = cliente.Apellido;
                    cmd.Parameters.Add("@telefono", SqlDbType.NVarChar).Value = cliente.Telefono;
                    cmd.Parameters.Add("@direccion", SqlDbType.NVarChar).Value = cliente.Direccion;

                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
                return RedirectToAction("ListarClientes");
            }
            return View(cliente);
        }
    }
}
