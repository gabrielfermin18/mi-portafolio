﻿using System.Data.SqlClient;
using Microsoft.AspNetCore.Mvc;
using ProyectoBigBen.Models;

namespace ProyectoBigBen.Controllers
{
    public class EmpleadosController : Controller
    {
        private string cad_cnx = "";

        public EmpleadosController(IConfiguration _cfg)
        {
            cad_cnx = _cfg.GetConnectionString("cn1");
        }

        public IActionResult Index()
        {
            return View();
        }

        //LISTADO DE EMPLEADOS
        private IEnumerable<Empleados> ObtenerEmpleados()
        {
            List<Empleados> empleados = new List<Empleados>();
            using (SqlConnection con = new SqlConnection(cad_cnx))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("sp_ListarEmpleado", con);
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    empleados.Add(new Empleados()
                    {
                        id_empleado = dr.GetString(0),
                        nombre_empleado = dr.GetString(1),
                        apellido_empleado = dr.GetString(2),
                        rol = dr.GetString(3),
                        telefono = dr.GetString(4)
                    });
                }
            }
            return empleados;
        }

        //PAGINACION EN EL LISTADO
        public async Task<IActionResult> ListadoEmpleados(int p = 0)
        {
            int nr = 10;
            var empleadosList = ObtenerEmpleados().ToList();
            int tr = empleadosList.Count();
            int paginas = (tr + nr - 1) / nr;
            ViewBag.paginas = paginas;
            return View(await Task.Run(() => empleadosList.Skip(p * nr).Take(nr)));
        }

        //REGISTRAR EMPLEADO
        [HttpGet]
        public IActionResult RegistrarEmpleado()
        {
            string nuevoCodigo = GenerarNuevoCodigo();

            Empleados nuevoEmpleado = new Empleados
            {
                id_empleado = nuevoCodigo
            };

            return View(nuevoEmpleado);
        }

        private string GenerarNuevoCodigo()
        {
            string nuevoCodigo = "E0001";
            using (SqlConnection con = new SqlConnection(cad_cnx))
            {
                SqlCommand cmd = new SqlCommand("SELECT TOP 1 id_empleado FROM Empleado ORDER BY id_empleado DESC", con);
                con.Open();

                var resultado = cmd.ExecuteScalar();

                if (resultado != DBNull.Value)
                {
                    string ultimoCodigo = (string)resultado;
                    int numero = int.Parse(ultimoCodigo.Substring(1));
                    numero++;
                    nuevoCodigo = "E" + numero.ToString("D4");
                }
            }

            return nuevoCodigo;
        }

        [HttpPost]
        public IActionResult RegistrarEmpleado(Empleados objE)
        {
            string mensaje = "";
            using (SqlConnection con = new SqlConnection(cad_cnx))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("sp_InsertarEmpleado", con);
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    con.Open();
                    cmd.Parameters.AddWithValue("@id_empleado", objE.id_empleado);
                    cmd.Parameters.AddWithValue("@nombre", objE.nombre_empleado);
                    cmd.Parameters.AddWithValue("@apellido", objE.apellido_empleado);
                    cmd.Parameters.AddWithValue("@rol", objE.rol);
                    cmd.Parameters.AddWithValue("@telefono", objE.telefono);

                    int e = cmd.ExecuteNonQuery();
                    mensaje = $"registro insertado {e} correctamente";
                }
                catch (Exception ex)
                {
                    mensaje = ex.Message;
                }
            }
            ViewBag.mensaje = mensaje;

            return RedirectToAction("ListadoEmpleados", "Empleados");
        }

        //EDITAR EMPLEADOS
        [HttpGet]
        public IActionResult EditarEmpleado(string id)
        {
            Empleados emp = new Empleados();
            using (SqlConnection con = new SqlConnection(cad_cnx))
            {
                SqlCommand cmd = new SqlCommand("sp_ObtenerEmpleadoPorID @id_empleado", con);
                cmd.Parameters.AddWithValue("@id_empleado", id);
                con.Open();

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.Read())
                    {
                        emp.id_empleado = (string)dr["id_empleado"];
                        emp.nombre_empleado = (string)dr["nombre"];
                        emp.apellido_empleado = (string)dr["apellido"];
                        emp.rol = (string)dr["rol"];
                        emp.telefono = (string)dr["telefono"];
                    }
                }
            }
            return View(emp);
        }

        [HttpPost, ActionName("EditarEmpleado")]
        public IActionResult Editar_Post(Empleados objE)
        {
            string mensaje = "";

            using (SqlConnection con = new SqlConnection(cad_cnx))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("sp_ActualizarEmpleado", con);
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    con.Open();
                    cmd.Parameters.AddWithValue("@id_empleado", objE.id_empleado);
                    cmd.Parameters.AddWithValue("@nombre", objE.nombre_empleado);
                    cmd.Parameters.AddWithValue("@apellido", objE.apellido_empleado);
                    cmd.Parameters.AddWithValue("@rol", objE.rol);
                    cmd.Parameters.AddWithValue("@telefono", objE.telefono);

                    int e = cmd.ExecuteNonQuery();

                    mensaje = $"registro actualizado {e} correctamente";
                }
                catch (Exception ex)
                {
                    mensaje = ex.Message;
                }
            }
            ViewBag.mensaje = mensaje;

            return RedirectToAction("ListadoEmpleados", "Empleados");
        }

        //ELIMINAR
        [HttpGet]
        public IActionResult EliminarEmpleado(string id)
        {
            Empleados emp = new Empleados();
            using (SqlConnection con = new SqlConnection(cad_cnx))
            {
                SqlCommand cmd = new SqlCommand("sp_ObtenerEmpleadoPorID", con);
                cmd.Parameters.AddWithValue("@id_empleado", id);
                con.Open();

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    if (dr.Read())
                    {
                        emp.id_empleado = (string)dr["id_empleado"];
                        emp.nombre_empleado = (string)dr["nombre"];
                        emp.apellido_empleado = (string)dr["apellido"];
                        emp.rol = (string)dr["rol"];
                        emp.telefono = (string)dr["telefono"];
                    }
                }
            }
            return View(emp);
        }

        [HttpPost, ActionName("EliminarEmpleado")]
        public IActionResult EliminarEmp(string id)
        {
            string mensaje = "";

            using (SqlConnection con = new SqlConnection(cad_cnx))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("sp_EliminarEmpleado", con);
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    con.Open();
                    cmd.Parameters.AddWithValue("@id_empleado", id);
                    int c = cmd.ExecuteNonQuery();
                    mensaje = $"registro eliminado {c} correctamente";
                }
                catch (Exception ex)
                {
                    mensaje = ex.Message;
                }
            }
            ViewBag.mensaje = mensaje;
            return RedirectToAction("ListadoEmpleados");
        }
    }
}

