﻿using Microsoft.AspNetCore.Mvc;
using ProyectoBigBeng.Models;
using System.Data.SqlClient;
using System.Data;

public class DetallePedidoController : Controller
{
    private string cad_cnx = "";

    public DetallePedidoController(IConfiguration _cfg)
    {
        cad_cnx = _cfg.GetConnectionString("cn1");
    }

    // Crear Detalle Pedido (POST)
    [HttpPost]
    public IActionResult CrearDetallePedido(DetallePedido detallePedido)
    {
        if (ModelState.IsValid)
        {
            using (SqlConnection con = new SqlConnection(cad_cnx))
            {
                SqlCommand cmd = new SqlCommand("sp_InsertarDetallePedido", con)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.Add("@id_detalle", SqlDbType.NVarChar).Value = detallePedido.IdDetalle;
                cmd.Parameters.Add("@id_pedido", SqlDbType.NVarChar).Value = detallePedido.IdPedido;
                cmd.Parameters.Add("@id_pizza", SqlDbType.NVarChar).Value = detallePedido.IdPizza;
                cmd.Parameters.Add("@cantidad", SqlDbType.Int).Value = detallePedido.Cantidad;
                cmd.Parameters.Add("@subtotal", SqlDbType.Decimal).Value = detallePedido.Subtotal; // Ahora se calcula automáticamente

                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
            return RedirectToAction("ListarDetallePedidos");
        }
        return View(detallePedido);
    }

    // Listar Detalle de Pedidos
    public IActionResult ListarDetallePedidos(string searchCodigo)
    {
        List<DetallePedido> detallesPedido = new List<DetallePedido>();

        using (SqlConnection con = new SqlConnection(cad_cnx))
        {
            SqlCommand cmd;
            if (!string.IsNullOrEmpty(searchCodigo))
            {
                // Buscar por código
                cmd = new SqlCommand("sp_ObtenerDetallePedidoPorID", con)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.Add("@id_pedido", SqlDbType.NVarChar).Value = searchCodigo;
            }
            else
            {
                // Listar todos los detalles de los pedidos
                cmd = new SqlCommand("sp_ListarDetallePedidos", con)
                {
                    CommandType = CommandType.StoredProcedure
                };
            }

            con.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                detallesPedido.Add(new DetallePedido
                {
                    IdDetalle = reader["id_detalle"].ToString(),
                    IdPedido = reader["id_pedido"].ToString(),
                    IdPizza = reader["id_pizza"].ToString(),
                    Cantidad = Convert.ToInt32(reader["cantidad"]),
                    // No es necesario asignar Subtotal, ya que se calcula automáticamente
                    // Subtotal = Convert.ToDecimal(reader["subtotal"]) // Esto ya no es necesario
                });
            }
            con.Close();
        }

        return View(detallesPedido);
    }
}