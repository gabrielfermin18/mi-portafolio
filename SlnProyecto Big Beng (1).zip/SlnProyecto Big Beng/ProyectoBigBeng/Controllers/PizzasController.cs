﻿using Microsoft.AspNetCore.Mvc;
using ProyectoBigBeng.Models;
using Dapper;
using System.Data.SqlClient;
using System.Data;

namespace ProyectoBigBeng.Controllers
{
    public class PizzasController : Controller
    {
        private string cad_cnx = "";
        

        public PizzasController(IConfiguration _cfg)
        {
            cad_cnx = _cfg.GetConnectionString("cn1");
        }

        // Acción para listar las pizzas
        public IActionResult ListarPizzas(string searchCodigo)
        {
            List<Pizzas> pizzas = new List<Pizzas>();

            using (SqlConnection con = new SqlConnection(cad_cnx))
            {
                SqlCommand cmd;

                if (!string.IsNullOrEmpty(searchCodigo))
                {
                    // Busca por código de pizza
                    cmd = new SqlCommand("sp_ObtenerPizzaPorID", con)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                    cmd.Parameters.Add("@id_pizza", SqlDbType.NVarChar).Value = searchCodigo;
                }
                else
                {
                    // Lista todas las pizzas
                    cmd = new SqlCommand("sp_ListarPizzas", con)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                }

                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    pizzas.Add(new Pizzas
                    {
                        id_pizza = reader["id_pizza"].ToString(),
                        nombre = reader["nombre"].ToString(),
                        descripcion = reader["descripcion"].ToString(),
                        precio = reader["precio"] != DBNull.Value ? Convert.ToDecimal(reader["precio"]) : 0.0m
                    });
                }
                con.Close();
            }

            // Pasamos el parámetro a la vista para que sea usado en el formulario
            ViewData["searchCodigo"] = searchCodigo;

            return View(pizzas);
        }


        // Acción para ver una pizza por ID
        public async Task<IActionResult> LeerPizza(string id_pizza)
        {
            try
            {
                using (var connection = new SqlConnection(cad_cnx))
                {
                    await connection.OpenAsync();
                    string query = "EXEC sp_ObtenerPizzaPorID @id_pizza";
                    var pizza = await connection.QueryFirstOrDefaultAsync<Pizzas>(query, new { id_pizza });
                    if (pizza == null)
                    {
                        return NotFound();  // Si no se encuentra la pizza, devuelve 404
                    }
                    return View(pizza);
                }
            }
            catch (Exception)
            {
                return View("Error");
            }
        }

        // Acción para mostrar la vista de creación de pizza
        public IActionResult CrearPizza()
        {
            return View();
        }

        // Acción para insertar una pizza
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CrearPizza(Pizzas pizza)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    using (var connection = new SqlConnection(cad_cnx))
                    {
                        await connection.OpenAsync();
                        string query = "EXEC sp_InsertarPizza @id_pizza, @nombre, @descripcion, @precio";
                        await connection.ExecuteAsync(query, new { pizza.id_pizza, pizza.nombre, pizza.descripcion, pizza.precio });
                    }
                    return RedirectToAction("ListarPizzas");  // Redirige a la lista después de crear
                }
                catch (Exception)
                {
                    return View("Error");  // Muestra una vista de error si ocurre algún problema
                }
            }
            return View(pizza);  // Si el modelo no es válido, retorna la misma vista con el modelo
        }

        // Acción para mostrar la vista de edición de pizza
        public async Task<IActionResult> EditarPizza(string id_pizza)
        {
            try
            {
                using (var connection = new SqlConnection(cad_cnx))
                {
                    await connection.OpenAsync();
                    string query = "EXEC sp_ObtenerPizzaPorID @id_pizza";
                    var pizza = await connection.QueryFirstOrDefaultAsync<Pizzas>(query, new { id_pizza });
                    if (pizza == null)
                    {
                        return NotFound();  // Si no se encuentra la pizza, devuelve 404
                    }
                    return View(pizza);
                }
            }
            catch (Exception)
            {
                return View("Error");
            }
        }

        // Acción para actualizar una pizza
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditarPizza(Pizzas pizza)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    using (var connection = new SqlConnection(cad_cnx))
                    {
                        await connection.OpenAsync();
                        string query = "EXEC sp_ActualizarPizza @id_pizza, @nombre, @descripcion, @precio";
                        await connection.ExecuteAsync(query, new { pizza.id_pizza, pizza.nombre, pizza.descripcion, pizza.precio });
                    }
                    return RedirectToAction("ListarPizzas");  // Redirige a la lista después de editar
                }
                catch (Exception)
                {
                    return View("Error");
                }
            }
            return View(pizza);  // Si el modelo no es válido, retorna la misma vista con el modelo
        }

        // Acción para eliminar una pizza
        public async Task<IActionResult> EliminarPizza(string id_pizza)
        {
            try
            {
                using (var connection = new SqlConnection(cad_cnx))
                {
                    await connection.OpenAsync();
                    string query = "EXEC sp_EliminarPizza @id_pizza";
                    await connection.ExecuteAsync(query, new { id_pizza });
                }
                return RedirectToAction("ListarPizzas");  // Redirige a la lista después de eliminar
            }
            catch (Exception)
            {
                return View("Error");
            }
        }
    }
}

